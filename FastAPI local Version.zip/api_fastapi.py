from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional
import logging
from sqlalchemy import text

from chatbot_core import (
    is_outlet_query,
    is_product_query,
    is_math_query,
    safe_calculate,
    detect_missing_info,
    initialize_chatbot
)
from langchain.chains import RetrievalQA

app = FastAPI(
    title="ZUS Chatbot API",
    description="API for querying ZUS Coffee products and outlets",
    version="1.0.0"
)

# === Initialize Chatbot Core ===
llm, db_chain, vectorstore, keywords, summarizer_chain, memory, conversation = initialize_chatbot()
retriever = vectorstore.as_retriever() if vectorstore else None
db = db_chain.database

# === Request Schema ===
class QueryRequest(BaseModel):
    query: str

# === Routes ===
@app.get("/outlets")
async def get_outlets(city: Optional[str] = None, state: Optional[str] = None):
    query = "SELECT * FROM outlets"
    filters = []
    if city:
        filters.append(f"city LIKE '%{city}%'")
    if state:
        filters.append(f"state LIKE '%{state}%'")
    if filters:
        query += " WHERE " + " AND ".join(filters)

    try:
        with db._engine.connect() as conn:
            result = conn.execute(text(query)).fetchall()
        data = [dict(row._mapping) for row in result]
        return {"count": len(data), "data": data}
    except Exception as e:
        logging.error("DB error: %s", e)
        return {"error": "Failed to fetch outlets"}

@app.post("/products")
async def ask_products(req: QueryRequest):
    if not retriever:
        return {"error": "Vectorstore not loaded"}
    try:
        qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
        result = qa_chain.run(req.query)
        return {"query": req.query, "answer": result}
    except Exception as e:
        logging.error("Product query error: %s", e)
        return {"error": "Product query failed"}
