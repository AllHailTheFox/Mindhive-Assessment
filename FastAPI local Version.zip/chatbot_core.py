import os
import re
import ast
import math
import logging
from dotenv import load_dotenv
from sqlalchemy import text

from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.chains import RetrievalQA
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate as CorePromptTemplate
from langchain_community.utilities import SQLDatabase
from langchain_community.vectorstores import FAISS
from langchain_experimental.sql import SQLDatabaseChain

# Load .env
load_dotenv()

# === Helper Functions ===
def is_outlet_query(user_input: str) -> bool:
    return any(kw in user_input.lower() for kw in [
        "outlet", "location", "shop", "address", "branch", "open", "opening", "close",
        "closing", "time", "city", "state", "days", "phone", "contact", "number"
    ])

def is_product_query(text: str) -> bool:
    return any(kw in text.lower() for kw in [
        "product", "products", "items", "catalog", "what do you have", "available",
        "how many", "price", "cost", "how much", "menu", "drink", "coffee",
        "matcha", "chocolate", "beverage", "flavor", "sell", "buy"
    ])

def detect_missing_info(user_input: str, history: str, keywords: set) -> str:
    combined = (history + "\n" + user_input).lower()
    if re.search(r"(how many|which|list all|what.*state|what.*city|how many.*state|states.*have)", combined):
        return ""
    if not any(keyword in combined for keyword in keywords):
        return "location"
    return ""

def is_math_query(text: str) -> bool:
    return any(op in text for op in [
        "+", "-", "*", "/", "^", "square root", "cube root", "power", "raised to", "mod",
        "modulus", "remainder", "multiply", "divide", "quotient", "add", "sum", "plus",
        "subtract", "minus", "difference", "average", "mean", "median", "mode",
        "percentage", "percent of", "calculate", "how much is", "what is", "total of"
    ])

def safe_calculate(query: str) -> str:
    logging.info("Performing calculation for query: %s", query)
    try:
        query = query.lower().replace("square root of", "math.sqrt").replace("^", "**")
        expressions = re.findall(r"(math\.sqrt\(\d+\)|\d+(\.\d+)?\s*[\+\-\*/]\s*\d+(\.\d+)?)", query)
        if not expressions:
            return "Sorry, I couldn't find any valid math expression."
        results = []
        for expr_tuple in expressions:
            expr = expr_tuple[0]
            result = eval(expr, {"math": math, "__builtins__": {}})
            results.append(f"{expr.strip()} = {result}")
        return "\n".join(results)
    except Exception as e:
        logging.error("Calculator error: %s", e)
        return "Sorry, I couldn't calculate that."

def get_outlet_keywords(db) -> set:
    try:
        with db._engine.connect() as conn:
            cities = [row[0].lower() for row in conn.execute(text("SELECT DISTINCT city FROM outlets")).fetchall()]
            states = [row[0].lower() for row in conn.execute(text("SELECT DISTINCT state FROM outlets")).fetchall()]
            names = [row[0].lower() for row in conn.execute(text("SELECT DISTINCT shop_name FROM outlets")).fetchall()]
            return set(cities + states + names)
    except Exception as e:
        logging.error("Failed to load outlet keywords: %s", e)
        return set()

def load_faiss_vectorstore(path="faiss_zus_products"):
    try:
        embedder = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        return FAISS.load_local(path, embeddings=embedder, allow_dangerous_deserialization=True)
    except Exception as e:
        logging.error("Failed to load FAISS vectorstore: %s", e)
        return None

# === Initialization ===
def initialize_chatbot():
    openai_key = os.getenv("OPENAI_API_KEY")
    db_path = os.getenv("DB_PATH")

    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.3, openai_api_key=openai_key)
    db = SQLDatabase.from_uri(f"sqlite:///{db_path}")
    db_chain = SQLDatabaseChain(llm=llm, database=db, verbose=False, return_intermediate_steps=True)
    keywords = get_outlet_keywords(db)
    vectorstore = load_faiss_vectorstore()

    summarizer_prompt = CorePromptTemplate.from_template("""
You are a helpful assistant for ZUS Coffee. A user asked:

{question}

Here is the raw result from the database:
{data}

If any data is missing, clearly state that. Otherwise, summarize the outlet names and their closing times accurately.
""")
    summarizer_chain = summarizer_prompt | llm | StrOutputParser()

    memory = ConversationBufferMemory()
    prompt = PromptTemplate(
        input_variables=["history", "input"],
        template="""
You are a helpful chatbot for ZUS Coffee. If the user asks something general, try to be helpful and polite.

Conversation history:
{history}
User: {input}
Bot:"""
    )
    conversation = ConversationChain(llm=llm, memory=memory, prompt=prompt)

    return llm, db_chain, vectorstore, keywords, summarizer_chain, memory, conversation
